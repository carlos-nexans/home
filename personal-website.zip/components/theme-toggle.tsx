"use client"

import { Monitor, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"

export function ThemeToggle() {
  const { theme, nextTheme } = useTheme()

  return (
    <Button variant="ghost" size="icon" onClick={nextTheme} className="rounded-full">
      <Sun className={`h-5 w-5 rotate-0 scale-100 transition-all ${theme !== "light" ? "absolute scale-0" : ""}`} />
      <Moon className={`h-5 w-5 rotate-0 scale-100 transition-all ${theme !== "dark" ? "absolute scale-0" : ""}`} />
      <Monitor
        className={`h-5 w-5 rotate-0 scale-100 transition-all ${theme !== "system" ? "absolute scale-0" : ""}`}
      />
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}

