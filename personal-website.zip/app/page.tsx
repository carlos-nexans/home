"use client"

import { Header } from "../components/header"

export default function SyntheticV0PageForDeployment() {
  return <Header />
}